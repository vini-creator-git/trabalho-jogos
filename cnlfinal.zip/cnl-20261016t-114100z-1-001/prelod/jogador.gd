extends CharacterBody2D
## Jogador com sistema de vida, ataque corpo a corpo, dano e cura.

signal vida_alterada(vida: int, vida_maxima: int)
signal morreu

const SPEED = 80.0

@export var vida_maxima: int = 5
@export var dano_ataque: int = 1
@export var tempo_invencivel: float = 1.0
@export var duracao_ataque: float = 0.18
@export var recarga_ataque: float = 0.4

var vida: int
var _ultima_direcao := Vector2.RIGHT
var _atacando := false
var _invulneravel := false
var _recarga := 0.0
var _atingidos: Array[Node] = []

@onready var anim: AnimatedSprite2D = $"Animação"
@onready var area_ataque: Area2D = $Ataque
@onready var golpe: Sprite2D = $Ataque/Golpe


func _ready() -> void:
	add_to_group("jogador")
	vida = vida_maxima
	golpe.visible = false
	area_ataque.body_entered.connect(_ao_entrar_na_area_ataque)
	vida_alterada.emit(vida, vida_maxima)


func _physics_process(delta: float) -> void:
	_recarga = max(0.0, _recarga - delta)

	# Leitura de entrada do usuário
	velocity = Vector2.ZERO
	if Input.is_action_pressed("ui_left"):
		velocity.x -= 1.0
	if Input.is_action_pressed("ui_right"):
		velocity.x += 1.0
	if Input.is_action_pressed("ui_up"):
		velocity.y -= 1.0
	if Input.is_action_pressed("ui_down"):
		velocity.y += 1.0

	if velocity.length() > 0.0:
		_ultima_direcao = velocity.normalized()
		velocity = velocity.normalized() * SPEED

	move_and_slide()

	# Escolhendo a animação
	if not _atacando:
		if velocity == Vector2.ZERO:
			anim.play("idle")
		else:
			anim.play("walk")

	# Direção da animação (direita/esquerda)
	if velocity.x < 0.0:
		anim.flip_h = true
	elif velocity.x > 0.0:
		anim.flip_h = false

	if Input.is_action_just_pressed("atacar") and not _atacando and _recarga <= 0.0:
		_atacar()


func _atacar() -> void:
	_atacando = true
	_recarga = recarga_ataque
	_atingidos.clear()

	area_ataque.position = Vector2(6, 2) + _ultima_direcao * 13.0
	golpe.rotation = _ultima_direcao.angle()
	golpe.modulate.a = 0.0
	golpe.visible = true

	var t := create_tween()
	t.tween_property(golpe, "modulate:a", 1.0, duracao_ataque * 0.3)
	t.tween_property(golpe, "modulate:a", 0.0, duracao_ataque * 0.7)

	# Acerta quem já está dentro do alcance no início do golpe.
	for corpo in area_ataque.get_overlapping_bodies():
		_acertar(corpo)

	await get_tree().create_timer(duracao_ataque).timeout

	golpe.visible = false
	_atacando = false


func _ao_entrar_na_area_ataque(corpo: Node2D) -> void:
	if _atacando:
		_acertar(corpo)


func _acertar(corpo: Node) -> void:
	if _atingidos.has(corpo):
		return
	if corpo.is_in_group("inimigo") and corpo.has_method("receber_dano"):
		_atingidos.append(corpo)
		corpo.receber_dano(dano_ataque)


func receber_dano(quantidade: int = 1) -> void:
	if _invulneravel or vida <= 0:
		return

	vida = max(0, vida - quantidade)
	vida_alterada.emit(vida, vida_maxima)

	if vida <= 0:
		_invulneravel = true
		morreu.emit()
		set_physics_process(false)
		anim.play("idle")
		_animacao_de_morte()
		return

	_invulneravel = true
	var t := create_tween()
	t.tween_property(anim, "modulate", Color(1.0, 0.3, 0.3, 0.6), 0.08)
	t.tween_property(anim, "modulate", Color.WHITE, 0.3)
	await get_tree().create_timer(tempo_invencivel).timeout
	_invulneravel = false


func _animacao_de_morte() -> void:
	var t := create_tween()
	t.set_parallel(true)
	t.tween_property(anim, "modulate", Color(1.0, 1.0, 1.0, 0.0), 0.8)
	t.tween_property(anim, "rotation", deg_to_rad(90.0), 0.8)


func curar(quantidade: int = 1) -> void:
	if vida <= 0 or vida >= vida_maxima:
		return
	vida = min(vida_maxima, vida + quantidade)
	vida_alterada.emit(vida, vida_maxima)
