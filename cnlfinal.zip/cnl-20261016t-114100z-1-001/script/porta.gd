class_name Porta
extends Area2D
## Porta de saída. Começa trancada (escurecida) e só libera quando o
## gerenciador a destranca (após todos os inimigos serem derrotados).

signal jogador_passou

var _liberada := false


func _ready() -> void:
	add_to_group("porta")
	body_entered.connect(_ao_entrar_no_corpo)
	trancar()


func trancar() -> void:
	_liberada = false
	modulate = Color(0.45, 0.45, 0.5, 1.0)


func destrancar() -> void:
	_liberada = true
	modulate = Color.WHITE
	var t := create_tween()
	t.tween_property(self, "scale", Vector2(1.1, 1.1), 0.15)
	t.tween_property(self, "scale", Vector2.ONE, 0.15)


func _ao_entrar_no_corpo(corpo: Node2D) -> void:
	if _liberada and corpo.is_in_group("jogador"):
		jogador_passou.emit()
