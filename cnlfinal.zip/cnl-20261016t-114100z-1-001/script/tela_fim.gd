class_name TelaFim
extends CanvasLayer
## Tela de fim (derrota ou vitória), com opções de reiniciar e voltar ao menu.

@onready var titulo: Label = $Centro/Painel/VBox/Titulo


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	add_to_group("tela_fim")
	visible = false


func mostrar(texto: String, cor: Color) -> void:
	titulo.text = texto
	titulo.add_theme_color_override("font_color", cor)
	visible = true
	get_tree().paused = true


func _on_reiniciar_pressed() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _on_menu_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://prelod/menucndl.tscn")