class_name Pocao
extends Area2D
## Poção: ao ser encostada pelo jogador, cura-o e avisa o gerenciador
## (que faz surgir uma nova poção no mapa).

signal coletada

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D


func _ready() -> void:
	add_to_group("pocao")
	body_entered.connect(_ao_entrar_no_corpo)

	var base_y: float = sprite.position.y
	var t := create_tween().set_loops()
	t.tween_property(sprite, "position:y", base_y - 2.0, 0.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	t.tween_property(sprite, "position:y", base_y, 0.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func _ao_entrar_no_corpo(corpo: Node2D) -> void:
	if corpo.is_in_group("jogador") and corpo.has_method("curar"):
		corpo.curar(1)
		coletada.emit()
		queue_free()