extends CanvasLayer
## Menu de pause. Alternado pela tecla Esc (ação "ui_cancel").


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false


func _unhandled_input(evento: InputEvent) -> void:
	if evento.is_action_pressed("ui_cancel"):
		alternar()
		get_viewport().set_input_as_handled()


func alternar() -> void:
	if get_tree().paused:
		retomar()
	elif not _fim_visivel():
		get_tree().paused = true
		visible = true


func _fim_visivel() -> bool:
	for no in get_tree().get_nodes_in_group("tela_fim"):
		if no is CanvasLayer and (no as CanvasLayer).visible:
			return true
	return false


func retomar() -> void:
	get_tree().paused = false
	visible = false


func _on_continuar_pressed() -> void:
	retomar()


func _on_reiniciar_pressed() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _on_menu_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://prelod/menucndl.tscn")