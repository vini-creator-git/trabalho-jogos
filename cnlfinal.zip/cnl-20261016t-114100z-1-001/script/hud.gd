class_name Hud
extends CanvasLayer
## Mostra a vida do jogador como uma fileira de corações.

const TEXTURA := preload("res://PNG/dungeon-01.png")
const CORACAO_CHEIO := Rect2(0, 48, 16, 16)
const CORACAO_VAZIO := Rect2(32, 48, 16, 16)

@onready var caixa: HBoxContainer = $HBoxContainer


func atualizar(vida: int, maxima: int) -> void:
	for filho in caixa.get_children():
		filho.queue_free()

	for i in range(maxima):
		var textura := AtlasTexture.new()
		textura.atlas = TEXTURA
		textura.region = CORACAO_CHEIO if i < vida else CORACAO_VAZIO

		var coracao := TextureRect.new()
		coracao.texture = textura
		coracao.custom_minimum_size = Vector2(16, 16)
		coracao.stretch_mode = TextureRect.STRETCH_KEEP
		coracao.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		caixa.add_child(coracao)