class_name Inimigo
extends CharacterBody2D
## Inimigo que persegue o jogador. Ao perder toda a vida, toca uma animação
## de morte (encolhe, gira e desvanece) e avisa o gerenciador através do sinal.

signal morreu

@export var vida_maxima: int = 2
@export var velocidade: float = 38.0
@export var dano_contato: int = 1

var vida: int
var _morto := false
var _jogador: Node2D = null
var _tempo := 0.0

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var area_dano: Area2D = $AreaDano
@onready var forma: CollisionShape2D = $CollisionShape2D


func _ready() -> void:
	add_to_group("inimigo")
	vida = vida_maxima
	_jogador = get_tree().get_first_node_in_group("jogador")
	area_dano.body_entered.connect(_ao_entrar_no_corpo)


func _physics_process(delta: float) -> void:
	if _morto:
		return

	var direcao := Vector2.ZERO
	if is_instance_valid(_jogador):
		var ate_jogador: Vector2 = _jogador.global_position - global_position
		if ate_jogador.length() > 3.0:
			direcao = ate_jogador.normalized()

	velocity = direcao * velocidade
	move_and_slide()

	if direcao.x != 0.0:
		sprite.flip_h = direcao.x < 0.0

	# Leve balanço para dar vida ao inimigo.
	_tempo += delta
	sprite.position.y = -1.306 + sin(_tempo * 6.0) * 0.6


func receber_dano(quantidade: int = 1) -> void:
	if _morto:
		return

	vida -= quantidade
	_piscar()
	if vida <= 0:
		morrer()


func _piscar() -> void:
	sprite.modulate = Color(1.0, 0.35, 0.35)
	var t := create_tween()
	t.tween_property(sprite, "modulate", Color.WHITE, 0.25)


func morrer() -> void:
	if _morto:
		return
	_morto = true
	velocity = Vector2.ZERO
	set_physics_process(false)
	forma.set_deferred("disabled", true)
	area_dano.set_deferred("monitoring", false)
	morreu.emit()
	_animacao_de_morte()


func _animacao_de_morte() -> void:
	# Animação de morte: pisca, se achata, gira e desvanece.
	sprite.modulate = Color.WHITE
	var t := create_tween()
	t.set_parallel(true)
	t.tween_property(sprite, "modulate", Color(1.0, 1.0, 1.0, 0.0), 0.6).set_delay(0.15)
	t.tween_property(sprite, "scale", Vector2(1.4, 0.4), 0.6).set_ease(Tween.EASE_OUT)
	t.tween_property(sprite, "rotation", deg_to_rad(180.0), 0.6)
	t.tween_property(sprite, "position:y", sprite.position.y + 4.0, 0.6)
	await t.finished
	queue_free()


func _ao_entrar_no_corpo(corpo: Node2D) -> void:
	if _morto:
		return
	if corpo.is_in_group("jogador") and corpo.has_method("receber_dano"):
		corpo.receber_dano(dano_contato)