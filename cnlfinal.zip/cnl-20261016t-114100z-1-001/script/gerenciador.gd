class_name Gerenciador
extends Node2D
## Gerenciador do nível: gera inimigos e poções em posições livres, controla a
## contagem de inimigos vivos (libera a porta) e mostra as telas de fim.

const CENA_INIMIGO := preload("res://prelod/inimigos.tscn")
const CENA_POCAO := preload("res://prelod/pocao.tscn")

## Tiles das decorações que possuem colisão (não podem ser usados para surgir).
const ATLAS_SOLIDOS: Array[Vector2i] = [Vector2i(0, 5), Vector2i(0, 6), Vector2i(0, 7)]
const CELULA_MIN := Vector2i(2, 2)
const CELULA_MAX := Vector2i(36, 17)

@export var quantidade_inimigos: int = 5

var inimigos_restantes: int = 0

@onready var gerador_inimigos: Node2D = $geradorini
@onready var gerador_pocoes: Node2D = $geradorpoc
# Tipados como Variant para não dependerem do registro global de class_name.
@onready var jogador: Variant = $mundo/jogador
@onready var porta: Variant = $porta
@onready var hud: Variant = $HUD
@onready var tela_fim: Variant = $TelaFim

@onready var chao: TileMapLayer = $mundo/chao
@onready var paredes: TileMapLayer = $mundo/paredes
@onready var decoracoes: TileMapLayer = $mundo/decoracoes


func _ready() -> void:
	randomize()
	jogador.vida_alterada.connect(_ao_alterar_vida)
	jogador.morreu.connect(_ao_jogador_morrer)
	porta.jogador_passou.connect(_ao_passar_pela_porta)

	_ao_alterar_vida(jogador.vida, jogador.vida_maxima)

	gerar_inimigos()
	gerar_pocao()


func _celula_livre(celula: Vector2i) -> bool:
	if chao.get_cell_source_id(celula) == -1:
		return false
	if paredes.get_cell_source_id(celula) != -1:
		return false
	if decoracoes.get_cell_source_id(celula) != -1:
		if decoracoes.get_cell_atlas_coords(celula) in ATLAS_SOLIDOS:
			return false
	var celula_jogador := Vector2i(jogador.global_position / 16.0)
	if celula == celula_jogador:
		return false
	return true


func _posicao_aleatoria() -> Vector2:
	var celula := Vector2i(CELULA_MIN.x, CELULA_MIN.y)
	for _i in range(40):
		celula = Vector2i(
			randi_range(CELULA_MIN.x, CELULA_MAX.x),
			randi_range(CELULA_MIN.y, CELULA_MAX.y))
		if _celula_livre(celula):
			break
	return Vector2(celula * 16) + Vector2(8, 8)


func gerar_inimigos() -> void:
	for _i in range(quantidade_inimigos):
		var inimigo: Variant = CENA_INIMIGO.instantiate()
		inimigo.position = _posicao_aleatoria()
		gerador_inimigos.add_child(inimigo)
		inimigo.morreu.connect(_ao_inimigo_morrer)
		inimigos_restantes += 1


func gerar_pocao() -> void:
	var pocao: Variant = CENA_POCAO.instantiate()
	pocao.position = _posicao_aleatoria()
	gerador_pocoes.add_child(pocao)
	pocao.coletada.connect(_ao_coletar_pocao)


func _ao_coletar_pocao() -> void:
	# Cada poção tomada faz surgir uma nova.
	await get_tree().create_timer(0.8).timeout
	gerar_pocao()


func _ao_inimigo_morrer() -> void:
	inimigos_restantes = max(0, inimigos_restantes - 1)
	if inimigos_restantes == 0:
		porta.destrancar()


func _ao_alterar_vida(vida: int, maxima: int) -> void:
	hud.atualizar(vida, maxima)


func _ao_jogador_morrer() -> void:
	tela_fim.mostrar("VOCÊ MORREU", Color(0.85, 0.2, 0.2))


func _ao_passar_pela_porta() -> void:
	porta.set_deferred("monitoring", false)
	tela_fim.mostrar("VOCÊ VENCEU!", Color(0.3, 0.85, 0.4))